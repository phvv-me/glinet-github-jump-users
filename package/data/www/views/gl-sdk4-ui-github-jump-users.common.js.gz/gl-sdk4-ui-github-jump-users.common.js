"use strict";
(() => {
const styleId = "github-jump-users-layout";
if (typeof document !== "undefined") {
  let style = document.getElementById(styleId);
  if (!style) {
    style = document.createElement("style");
    style.id = styleId;
    document.head.appendChild(style);
  }
  style.textContent = ".github-jump-users {\r\n  padding: 20px 0;\r\n}\r\n\r\n.github-jump-users .main-action,\r\n.github-jump-users .dialog-button {\r\n  min-width: 124px;\r\n  height: 36px;\r\n}\r\n\r\n.github-jump-users .layout-notice {\n  margin: 20px 0;\n}\n\n.github-jump-users .settings-panel {\n  padding: 20px;\n  margin-bottom: 20px;\n  background: var(--background-card);\n  border-radius: 5px;\n}\n\n.github-jump-users .settings-title {\n  margin-bottom: 15px;\n  color: var(--text-title);\n  font-size: 16px;\n  font-weight: 700;\n}\n\n.github-jump-users .settings-grid {\n  display: grid;\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  gap: 15px;\n}\n\n.github-jump-users .settings-grid label > span {\n  display: block;\n  margin-bottom: 6px;\n  color: var(--text-weak);\n  font-size: 13px;\n}\n\n.github-jump-users .settings-targets {\n  grid-column: 1 / -1;\n}\n\n.github-jump-users .settings-tip {\n  margin: 15px 0;\n}\n\r\n.github-jump-users .account-pane {\r\n  padding: 20px;\r\n}\r\n\r\n.github-jump-users .account-summary {\r\n  margin-bottom: 20px;\r\n}\r\n\r\n.github-jump-users .member-list-title {\r\n  min-height: 40px;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 0 10px;\r\n  margin-bottom: 10px;\r\n  color: var(--text-subtitle);\r\n  font-size: 14px;\r\n  font-weight: 700;\r\n  background-color: var(--background-subtitle);\r\n  border-radius: 5px;\r\n}\r\n\r\n.github-jump-users .member-list-title .btn-text {\r\n  font-weight: 400;\r\n}\r\n\r\n.github-jump-users .member-list-title .iconfont {\r\n  margin-right: 6px;\r\n}\r\n\r\n.github-jump-users .member-dialog .el-dialog {\r\n  width: 90%;\r\n  max-width: 600px;\r\n}\r\n\r\n.github-jump-users .dialog-warning {\r\n  margin-bottom: 10px;\r\n}\r\n\r\n.github-jump-users .dialog-form > li {\r\n  min-height: 50px;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 5px 10px;\r\n  color: var(--text-regular);\r\n}\r\n\r\n.github-jump-users .dialog-form > li > div:first-child {\r\n  flex: 1;\r\n  margin-right: 10px;\r\n  color: var(--text-weak);\r\n}\r\n\r\n.github-jump-users .dialog-form > li > div:last-child {\r\n  width: 70%;\r\n  min-width: 160px;\r\n  max-width: 320px;\r\n}\r\n\r\n.github-jump-users .dialog-actions,\r\n.github-jump-users .drawer-actions {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  gap: 10px;\r\n}\r\n\r\n.github-jump-users .config-title {\r\n  margin-bottom: 10px;\r\n}\r\n\r\n.github-jump-users .config-help {\r\n  margin-bottom: 15px;\r\n  color: var(--text-weak);\r\n}\r\n\r\n@media screen and (max-width: 480px) {\n  .github-jump-users .settings-grid {\n    grid-template-columns: 1fr;\n  }\n\n  .github-jump-users .dialog-form > li {\r\n    align-items: stretch;\r\n    flex-direction: column;\r\n  }\r\n\r\n  .github-jump-users .dialog-form > li > div:first-child,\r\n  .github-jump-users .dialog-form > li > div:last-child {\r\n    width: 100%;\r\n    max-width: none;\r\n    margin: 0 0 8px;\r\n  }\r\n}\r\n";
}
const component = ({
  name: "github-jump-users",

  data() {
    return {
      loading: true,
      working: false,
      error: "",
      selectedConfig: "",
      selectedConfigTitle: "",
      activeAccount: "root",
      showAddUser: false,
      status: { accounts: [] },
      settings: {
        endpoint: "",
        ssh_port: 22,
        ssh_alias: "flint-home",
        targets: "",
      },
      memberForm: {
        github: "",
      },
    };
  },

  created() {
    this.loadStatus();
  },

  computed: {
    githubRules() {
      return [
        { required: true, message: "Enter a GitHub username", trigger: "blur" },
        {
          pattern: /^(?!-)(?!.*--)[A-Za-z0-9-]{0,38}[A-Za-z0-9]$/,
          message: "Enter a valid GitHub username",
          trigger: "blur",
        },
      ];
    },
  },

  methods: {
    rpc(method, params = {}) {
      return window.$rpcRequest("call", [
        "sid",
        "github-jump-users",
        method,
        params,
      ]);
    },

    applyStatus(status) {
      this.status = status;
      this.settings = {
        endpoint: status.endpoint || "",
        ssh_port: status.ssh_port || 22,
        ssh_alias: status.ssh_alias || "flint-home",
        targets: (status.targets || []).join("\n"),
      };
      if (!status.accounts.some(({ username }) => username === this.activeAccount))
        this.activeAccount = status.accounts[0]?.username || "root";
    },

    async perform(operation, successMessage) {
      this.working = true;
      this.error = "";
      try {
        const status = await operation;
        if (!status.success) throw new Error(status.error || "The request failed");
        this.applyStatus(status);
        this.$message.closeAll();
        this.$message.success(successMessage);
        return true;
      } catch (error) {
        this.error = error?.message || "The request failed";
        return false;
      } finally {
        this.working = false;
      }
    },

    async loadStatus() {
      try {
        this.applyStatus(await this.rpc("get_status"));
      } catch (error) {
        this.error = error?.message || "Could not load access";
      } finally {
        this.loading = false;
      }
    },

    syncUsers() {
      return this.perform(
        this.rpc("sync_users"),
        "GitHub keys synchronized",
      );
    },

    saveSettings() {
      const targets = this.settings.targets
        .split(/\r?\n/)
        .map((target) => target.trim())
        .filter(Boolean);
      return this.perform(
        this.rpc("save_settings", { ...this.settings, targets }),
        "Connection settings saved",
      );
    },

    showAddDialog(account) {
      this.activeAccount = account;
      this.memberForm.github = "";
      this.showAddUser = true;
      this.$nextTick(() => this.$refs.memberForm.clearValidate());
    },

    async addMember() {
      if (!await this.$refs.memberForm.validate()) return;
      const params = {
        account: this.activeAccount,
        github: this.memberForm.github,
        confirm_root: false,
      };
      const assign = async () => {
        if (!await this.perform(this.rpc("add_member", params), "User assigned")) return;
        this.memberForm.github = "";
        this.showAddUser = false;
      };
      if (params.account === "root") {
        return this.$alert(
          `Grant ${params.github} full router administration?`,
          {
            confirmText: "Grant root access",
            confirmBtnType: "error",
            confirmAutoClose: false,
            onConfirm: async ({ close }) => {
              params.confirm_root = true;
              await assign();
              if (!this.error) close();
            },
          },
        );
      }
      return assign();
    },

    removeMember(account, member) {
      return this.$alert(
        `Remove ${member.github} from ${account.username}?`,
        {
          confirmText: "Remove",
          confirmBtnType: "error",
          confirmAutoClose: false,
          onConfirm: async ({ close }) => {
            await this.perform(
              this.rpc("remove_member", {
                account: account.username,
                github: member.github,
              }),
              "User removed",
            );
            if (!this.error) close();
          },
        },
      );
    },

    connectionConfig(account) {
      const alias = this.status.ssh_alias || "flint-home";
      const lines = [
        `Host ${alias}`,
        `  HostName ${this.status.endpoint}`,
        `  Port ${this.status.ssh_port}`,
        `  User ${account.username}`,
        "  RequestTTY no",
      ];

      if (account.mode === "jump") {
        lines.push(
          "",
          "Host {target_alias}",
          "  HostName {target_host}",
          "  Port {target_port}",
          "  User {target_user}",
          "  IdentityFile ~/.ssh/id_ed25519",
          "  IdentitiesOnly yes",
          `  ProxyCommand ssh ${alias} connect %h %p`,
        );
      }
      return lines.join("\n");
    },

    showConfig(account, member) {
      this.selectedConfigTitle = `${account.username} for ${member.github}`;
      this.selectedConfig = this.connectionConfig(account);
    },

    closeConfig() {
      this.selectedConfig = "";
      this.selectedConfigTitle = "";
    },

    copyConfig() {
      return this.$copyText(this.selectedConfig)
        .then(() => {
          this.$message.closeAll();
          this.$message.success("SSH configuration copied");
        })
        .catch((error) => {
          this.error = error?.message || "Could not copy SSH configuration";
        });
    },

  },
});
component.render = function render() { var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"github-jump-users"},[_c('gl-title',{attrs:{"title":"GitHub Jump Users"}},[_c('gl-button',{staticClass:"main-action",attrs:{"type":"primary","loading":_vm.working},on:{"click":_vm.syncUsers}},[_vm._v(" Sync GitHub keys ")])],1),_c('gl-tips',{staticClass:"layout-notice",attrs:{"tips":"Assign GitHub SSH keys to the fixed root or restricted jump account.","sign":"none"}}),(_vm.error)?_c('gl-tips',{staticClass:"layout-notice",attrs:{"tips":_vm.error,"state":"error"}}):_vm._e(),(_vm.loading)?_c('gl-button',{attrs:{"loading":true,"disabled":""}},[_vm._v(" Loading access list ")]):[_c('div',{staticClass:"settings-panel"},[_c('div',{staticClass:"settings-title"},[_vm._v("Connection settings")]),_c('div',{staticClass:"settings-grid"},[_c('label',[_c('span',[_vm._v("Router DDNS or Tailscale hostname")]),_c('el-input',{attrs:{"placeholder":"example.glddns.com"},model:{value:(_vm.settings.endpoint),callback:function ($$v) {_vm.$set(_vm.settings, "endpoint", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"settings.endpoint"}})],1),_c('label',[_c('span',[_vm._v("SSH alias")]),_c('el-input',{attrs:{"placeholder":"flint-home"},model:{value:(_vm.settings.ssh_alias),callback:function ($$v) {_vm.$set(_vm.settings, "ssh_alias", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"settings.ssh_alias"}})],1),_c('label',[_c('span',[_vm._v("Router SSH port")]),_c('el-input',{attrs:{"type":"number"},model:{value:(_vm.settings.ssh_port),callback:function ($$v) {_vm.$set(_vm.settings, "ssh_port", _vm._n($$v))},expression:"settings.ssh_port"}})],1),_c('label',{staticClass:"settings-targets"},[_c('span',[_vm._v("Allowed targets, one HOST:PORT per line")]),_c('el-input',{attrs:{"type":"textarea","autosize":{ minRows: 2, maxRows: 8 },"placeholder":"pedro-home:22"},model:{value:(_vm.settings.targets),callback:function ($$v) {_vm.$set(_vm.settings, "targets", $$v)},expression:"settings.targets"}})],1)]),_c('gl-tips',{staticClass:"settings-tip",attrs:{"tips":"The jump account is denied unless the requested destination exactly matches this allowlist.","state":"warning","sign":"status"}}),_c('gl-button',{attrs:{"type":"primary","loading":_vm.working},on:{"click":_vm.saveSettings}},[_vm._v(" Save connection settings ")])],1),_c('el-tabs',{staticClass:"is-card access-tabs",attrs:{"type":"card"},model:{value:(_vm.activeAccount),callback:function ($$v) {_vm.activeAccount=$$v},expression:"activeAccount"}},_vm._l((_vm.status.accounts),function(account){return _c('el-tab-pane',{key:account.username,attrs:{"label":((account.username) + " (" + (account.members.length) + ")"),"name":account.username}},[_c('div',{staticClass:"account-pane"},[_c('gl-tips',{staticClass:"account-summary",attrs:{"tips":account.mode === 'admin'
                ? ((account.label) + ". Full router administration.")
                : ((account.label) + ". Restricted jump access to reachable SSH targets."),"state":account.mode === 'admin' ? 'warning' : 'success',"sign":"status"}}),_c('div',{staticClass:"member-list-title"},[_c('span',[_vm._v("GitHub users")]),_c('span',{staticClass:"btn-text",on:{"click":function($event){return _vm.showAddDialog(account.username)}}},[_c('span',{staticClass:"iconfont icon-plus"}),_vm._v(" Add GitHub user ")])]),_c('gl-table',{attrs:{"data":account.members,"empty-text":"No GitHub users assigned"}},[_c('gl-table-column',{attrs:{"label":"GitHub user","min-width":"180"},scopedSlots:_vm._u([{key:"default",fn:function(scope){return [_c('a',{attrs:{"href":("https://github.com/" + (scope.row.github)),"target":"_blank","rel":"noopener noreferrer"}},[_vm._v(" "+_vm._s(scope.row.github)+" ")])]}}],null,true)}),_c('gl-table-column',{attrs:{"label":"Keys","min-width":"150"},scopedSlots:_vm._u([{key:"default",fn:function(scope){return [_vm._v(" "+_vm._s(scope.row.key_count)+" "+_vm._s(scope.row.key_types.join(", ") || "pending")+" ")]}}],null,true)}),_c('gl-table-column',{attrs:{"label":"Actions","width":"100","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(scope){return [_c('gl-dropdown',{attrs:{"dropdown-key":((account.username) + "-" + (scope.row.github))}},[_c('gl-dropdown-item',{on:{"click":function($event){return _vm.showConfig(account, scope.row)}}},[_c('span',{staticClass:"iconfont icon-set-config"}),_vm._v(" SSH config ")]),_c('gl-dropdown-item',{attrs:{"divided":""},on:{"click":function($event){return _vm.removeMember(account, scope.row)}}},[_c('span',{staticClass:"iconfont icon-delete"}),_vm._v(" Remove ")])],1)]}}],null,true)})],1)],1)])}),1),_c('el-dialog',{staticClass:"member-dialog",attrs:{"visible":_vm.showAddUser,"title":"Add GitHub user","close-on-click-modal":false},on:{"update:visible":function($event){_vm.showAddUser = $event}}},[_c('div',{staticClass:"dialog-main"},[(_vm.activeAccount === 'root')?_c('gl-tips',{staticClass:"dialog-warning",attrs:{"tips":"This grants full router administration.","state":"warning"}}):_vm._e(),_c('el-form',{ref:"memberForm",attrs:{"model":_vm.memberForm}},[_c('ul',{staticClass:"dialog-form"},[_c('li',[_c('div',[_vm._v("GitHub username")]),_c('div',[_c('el-form-item',{attrs:{"prop":"github","rules":_vm.githubRules}},[_c('el-input',{attrs:{"maxlength":"39","placeholder":"GitHub username"},model:{value:(_vm.memberForm.github),callback:function ($$v) {_vm.$set(_vm.memberForm, "github", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"memberForm.github"}})],1)],1)])])])],1),_c('template',{slot:"footer"},[_c('div',{staticClass:"dialog-actions"},[_c('gl-button',{staticClass:"dialog-button",on:{"click":function($event){_vm.showAddUser = false}}},[_vm._v(" Cancel ")]),_c('gl-button',{staticClass:"dialog-button",attrs:{"type":"primary","loading":_vm.working},on:{"click":_vm.addMember}},[_vm._v(" Confirm ")])],1)])],2),_c('gl-drawer',{attrs:{"visible":Boolean(_vm.selectedConfig),"title":"SSH configuration"},on:{"update:visible":_vm.closeConfig}},[_c('p',{staticClass:"config-title"},[_vm._v(_vm._s(_vm.selectedConfigTitle))]),_c('p',{staticClass:"config-help"},[_vm._v("Paste into ~/.ssh/config and replace the braced target values.")]),_c('el-input',{attrs:{"type":"textarea","value":_vm.selectedConfig,"readonly":"","autosize":{ minRows: 8, maxRows: 18 }}}),_c('template',{slot:"footer"},[_c('div',{staticClass:"drawer-actions"},[_c('gl-button',{staticClass:"dialog-button",on:{"click":_vm.closeConfig}},[_vm._v("Close")]),_c('gl-button',{staticClass:"dialog-button",attrs:{"type":"primary"},on:{"click":_vm.copyConfig}},[_vm._v(" Copy ")])],1)])],2)]],2) };
component.staticRenderFns = [];
return component;
})()
