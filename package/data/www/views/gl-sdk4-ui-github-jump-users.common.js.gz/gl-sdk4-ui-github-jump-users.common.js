"use strict";
(() => {
const styleId = "github-jump-users-layout";
if (typeof document !== "undefined") {
  let style = document.getElementById(styleId);
  if (!style) {
    style = document.createElement("style");
    style.id = styleId;
    document.head.appendChild(style);
  }
  style.textContent = ".github-jump-users {\n  padding: 20px 0;\n}\n\n.github-jump-users .main-action,\n.github-jump-users .dialog-button {\n  min-width: 124px;\n  height: 36px;\n}\n\n.github-jump-users .layout-notice {\n  margin: 20px 0;\n}\n\n.github-jump-users .account-pane {\n  padding: 20px;\n}\n\n.github-jump-users .account-summary {\n  margin-bottom: 20px;\n}\n\n.github-jump-users .member-list-title {\n  min-height: 40px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 0 10px;\n  margin-bottom: 10px;\n  color: var(--text-subtitle);\n  font-size: 14px;\n  font-weight: 700;\n  background-color: var(--background-subtitle);\n  border-radius: 5px;\n}\n\n.github-jump-users .member-list-title .btn-text {\n  font-weight: 400;\n}\n\n.github-jump-users .member-list-title .iconfont {\n  margin-right: 6px;\n}\n\n.github-jump-users .member-dialog .el-dialog {\n  width: 90%;\n  max-width: 600px;\n}\n\n.github-jump-users .dialog-warning {\n  margin-bottom: 10px;\n}\n\n.github-jump-users .dialog-form > li {\n  min-height: 50px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 5px 10px;\n  color: var(--text-regular);\n}\n\n.github-jump-users .dialog-form > li > div:first-child {\n  flex: 1;\n  margin-right: 10px;\n  color: var(--text-weak);\n}\n\n.github-jump-users .dialog-form > li > div:last-child {\n  width: 70%;\n  min-width: 160px;\n  max-width: 320px;\n}\n\n.github-jump-users .dialog-actions,\n.github-jump-users .drawer-actions {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 10px;\n}\n\n.github-jump-users .config-title {\n  margin-bottom: 10px;\n}\n\n.github-jump-users .config-help {\n  margin-bottom: 15px;\n  color: var(--text-weak);\n}\n\n@media screen and (max-width: 480px) {\n  .github-jump-users .dialog-form > li {\n    align-items: stretch;\n    flex-direction: column;\n  }\n\n  .github-jump-users .dialog-form > li > div:first-child,\n  .github-jump-users .dialog-form > li > div:last-child {\n    width: 100%;\n    max-width: none;\n    margin: 0 0 8px;\n  }\n}\n";
}
const component = ({
  name: "github-jump-users",

  data() {
    return {
      loading: true,
      working: false,
      error: "",
      selectedConfig: "",
      selectedConfigTitle: "",
      activeAccount: "root",
      showAddUser: false,
      status: { accounts: [] },
      memberForm: {
        github: "",
      },
    };
  },

  created() {
    this.loadStatus();
  },

  computed: {
    githubRules() {
      return [
        { required: true, message: "Enter a GitHub username", trigger: "blur" },
        {
          pattern: /^(?!-)(?!.*--)[A-Za-z0-9-]{0,38}[A-Za-z0-9]$/,
          message: "Enter a valid GitHub username",
          trigger: "blur",
        },
      ];
    },
  },

  methods: {
    rpc(method, params = {}) {
      return window.$rpcRequest("call", [
        "sid",
        "github-jump-users",
        method,
        params,
      ]);
    },

    applyStatus(status) {
      this.status = status;
      if (!status.accounts.some(({ username }) => username === this.activeAccount))
        this.activeAccount = status.accounts[0]?.username || "root";
    },

    async perform(operation, successMessage) {
      this.working = true;
      this.error = "";
      try {
        const status = await operation;
        if (!status.success) throw new Error(status.error || "The request failed");
        this.applyStatus(status);
        this.$message.closeAll();
        this.$message.success(successMessage);
        return true;
      } catch (error) {
        this.error = error?.message || "The request failed";
        return false;
      } finally {
        this.working = false;
      }
    },

    async loadStatus() {
      try {
        this.applyStatus(await this.rpc("get_status"));
      } catch (error) {
        this.error = error?.message || "Could not load access";
      } finally {
        this.loading = false;
      }
    },

    syncUsers() {
      return this.perform(
        this.rpc("sync_users"),
        "GitHub keys synchronized",
      );
    },

    showAddDialog(account) {
      this.activeAccount = account;
      this.memberForm.github = "";
      this.showAddUser = true;
      this.$nextTick(() => this.$refs.memberForm.clearValidate());
    },

    async addMember() {
      if (!await this.$refs.memberForm.validate()) return;
      const params = {
        account: this.activeAccount,
        github: this.memberForm.github,
        confirm_root: false,
      };
      const assign = async () => {
        if (!await this.perform(this.rpc("add_member", params), "User assigned")) return;
        this.memberForm.github = "";
        this.showAddUser = false;
      };
      if (params.account === "root") {
        return this.$alert(
          `Grant ${params.github} full router administration?`,
          {
            confirmText: "Grant root access",
            confirmBtnType: "error",
            confirmAutoClose: false,
            onConfirm: async ({ close }) => {
              params.confirm_root = true;
              await assign();
              if (!this.error) close();
            },
          },
        );
      }
      return assign();
    },

    removeMember(account, member) {
      return this.$alert(
        `Remove ${member.github} from ${account.username}?`,
        {
          confirmText: "Remove",
          confirmBtnType: "error",
          confirmAutoClose: false,
          onConfirm: async ({ close }) => {
            await this.perform(
              this.rpc("remove_member", {
                account: account.username,
                github: member.github,
              }),
              "User removed",
            );
            if (!this.error) close();
          },
        },
      );
    },

    connectionConfig(account) {
      const lines = [
        "Host cvlab",
        `  HostName ${this.status.endpoint}`,
        `  Port ${this.status.ssh_port}`,
        `  User ${account.username}`,
        "  RequestTTY no",
      ];

      if (account.mode === "jump") {
        lines.push(
          "",
          "Host {target}",
          "  HostName {target}",
          "  Port 22",
          "  ProxyCommand ssh cvlab connect %h %p",
        );
      }
      return lines.join("\n");
    },

    showConfig(account, member) {
      this.selectedConfigTitle = `${account.username} for ${member.github}`;
      this.selectedConfig = this.connectionConfig(account);
    },

    closeConfig() {
      this.selectedConfig = "";
      this.selectedConfigTitle = "";
    },

    copyConfig() {
      return this.$copyText(this.selectedConfig)
        .then(() => {
          this.$message.closeAll();
          this.$message.success("SSH configuration copied");
        })
        .catch((error) => {
          this.error = error?.message || "Could not copy SSH configuration";
        });
    },

  },
});
component.render = function render() { var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"github-jump-users"},[_c('gl-title',{attrs:{"title":"GitHub Jump Users"}},[_c('gl-button',{staticClass:"main-action",attrs:{"type":"primary","loading":_vm.working},on:{"click":_vm.syncUsers}},[_vm._v(" Sync GitHub keys ")])],1),_c('gl-tips',{staticClass:"layout-notice",attrs:{"tips":"Assign GitHub SSH keys to the fixed root or restricted jump account.","sign":"none"}}),(_vm.error)?_c('gl-tips',{staticClass:"layout-notice",attrs:{"tips":_vm.error,"state":"error"}}):_vm._e(),(_vm.loading)?_c('gl-button',{attrs:{"loading":true,"disabled":""}},[_vm._v(" Loading access list ")]):[_c('el-tabs',{staticClass:"is-card access-tabs",attrs:{"type":"card"},model:{value:(_vm.activeAccount),callback:function ($$v) {_vm.activeAccount=$$v},expression:"activeAccount"}},_vm._l((_vm.status.accounts),function(account){return _c('el-tab-pane',{key:account.username,attrs:{"label":((account.username) + " (" + (account.members.length) + ")"),"name":account.username}},[_c('div',{staticClass:"account-pane"},[_c('gl-tips',{staticClass:"account-summary",attrs:{"tips":account.mode === 'admin'
                ? ((account.label) + ". Full router administration.")
                : ((account.label) + ". Restricted jump access to reachable SSH targets."),"state":account.mode === 'admin' ? 'warning' : 'success',"sign":"status"}}),_c('div',{staticClass:"member-list-title"},[_c('span',[_vm._v("GitHub users")]),_c('span',{staticClass:"btn-text",on:{"click":function($event){return _vm.showAddDialog(account.username)}}},[_c('span',{staticClass:"iconfont icon-plus"}),_vm._v(" Add GitHub user ")])]),_c('gl-table',{attrs:{"data":account.members,"empty-text":"No GitHub users assigned"}},[_c('gl-table-column',{attrs:{"label":"GitHub user","min-width":"180"},scopedSlots:_vm._u([{key:"default",fn:function(scope){return [_c('a',{attrs:{"href":("https://github.com/" + (scope.row.github)),"target":"_blank","rel":"noopener noreferrer"}},[_vm._v(" "+_vm._s(scope.row.github)+" ")])]}}],null,true)}),_c('gl-table-column',{attrs:{"label":"Keys","min-width":"150"},scopedSlots:_vm._u([{key:"default",fn:function(scope){return [_vm._v(" "+_vm._s(scope.row.key_count)+" "+_vm._s(scope.row.key_types.join(", ") || "pending")+" ")]}}],null,true)}),_c('gl-table-column',{attrs:{"label":"Actions","width":"100","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(scope){return [_c('gl-dropdown',{attrs:{"dropdown-key":((account.username) + "-" + (scope.row.github))}},[_c('gl-dropdown-item',{on:{"click":function($event){return _vm.showConfig(account, scope.row)}}},[_c('span',{staticClass:"iconfont icon-set-config"}),_vm._v(" SSH config ")]),_c('gl-dropdown-item',{attrs:{"divided":""},on:{"click":function($event){return _vm.removeMember(account, scope.row)}}},[_c('span',{staticClass:"iconfont icon-delete"}),_vm._v(" Remove ")])],1)]}}],null,true)})],1)],1)])}),1),_c('el-dialog',{staticClass:"member-dialog",attrs:{"visible":_vm.showAddUser,"title":"Add GitHub user","close-on-click-modal":false},on:{"update:visible":function($event){_vm.showAddUser = $event}}},[_c('div',{staticClass:"dialog-main"},[(_vm.activeAccount === 'root')?_c('gl-tips',{staticClass:"dialog-warning",attrs:{"tips":"This grants full router administration.","state":"warning"}}):_vm._e(),_c('el-form',{ref:"memberForm",attrs:{"model":_vm.memberForm}},[_c('ul',{staticClass:"dialog-form"},[_c('li',[_c('div',[_vm._v("GitHub username")]),_c('div',[_c('el-form-item',{attrs:{"prop":"github","rules":_vm.githubRules}},[_c('el-input',{attrs:{"maxlength":"39","placeholder":"GitHub username"},model:{value:(_vm.memberForm.github),callback:function ($$v) {_vm.$set(_vm.memberForm, "github", (typeof $$v === 'string'? $$v.trim(): $$v))},expression:"memberForm.github"}})],1)],1)])])])],1),_c('template',{slot:"footer"},[_c('div',{staticClass:"dialog-actions"},[_c('gl-button',{staticClass:"dialog-button",on:{"click":function($event){_vm.showAddUser = false}}},[_vm._v(" Cancel ")]),_c('gl-button',{staticClass:"dialog-button",attrs:{"type":"primary","loading":_vm.working},on:{"click":_vm.addMember}},[_vm._v(" Confirm ")])],1)])],2),_c('gl-drawer',{attrs:{"visible":Boolean(_vm.selectedConfig),"title":"SSH configuration"},on:{"update:visible":_vm.closeConfig}},[_c('p',{staticClass:"config-title"},[_vm._v(_vm._s(_vm.selectedConfigTitle))]),_c('p',{staticClass:"config-help"},[_vm._v("Paste into ~/.ssh/config and replace {target}.")]),_c('el-input',{attrs:{"type":"textarea","value":_vm.selectedConfig,"readonly":"","autosize":{ minRows: 8, maxRows: 18 }}}),_c('template',{slot:"footer"},[_c('div',{staticClass:"drawer-actions"},[_c('gl-button',{staticClass:"dialog-button",on:{"click":_vm.closeConfig}},[_vm._v("Close")]),_c('gl-button',{staticClass:"dialog-button",attrs:{"type":"primary"},on:{"click":_vm.copyConfig}},[_vm._v(" Copy ")])],1)])],2)]],2) };
component.staticRenderFns = [];
return component;
})()
